this program is written with python 3. In order to RUN it
simply run :

python3 front_end.py

or

/usr/local/python-3.5.0/bin/python3.5 front_end.py



Consideration:

This program will need all of expressions at once. it means that it will keep reading inputs until it sees $$ sign.

you can copy all of the test cases and see the entire results.

Since all of program is written in only one file. there is no make file for this phase.
